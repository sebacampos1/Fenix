<?php
	include("conecta.php");
	$recnome = $_GET["cpfnnpj"];
	$recemail = $_GET["nome"];
	$recmsg = $_GET["rginscric"];
	mysqli_query($conexao, "insert into dados(nome, email, msg) values('recnome', 'recemail', 'recmsg')");
	header("location:lista.php");
?>
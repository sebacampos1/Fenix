<!DOCTYPE html>
<html>
	<head> 
		<META CHARSET = "utf-8"/>
		<title>Lista</title>
		<!--<link type="text/css" href="css/estilo.css" rel="stylesheet">
		<link type="text/css" href = "font-awesome-4.6.0/css/font-awesome.min.css" rel = "stylesheet">
		-->
	</head>
	<body>
		<h1 class="titulo"> Listagem de dados - PHP</h1>
		<table width = "100%" border ="1" border-color="#EEE" cellspacing="0" cellpadding = "10">
			<tr>
				<td><strong> NOME</strong></td>
				<td><strong> CPF</strong></td>
				<td width = "10"><strong> RG</strong></td>
				<td width = "10"><strong> EMAIL</strong></td>
			</tr>
			<?php
				include("conecta.php");
				$nome=$_GET["nome"];
				$cpf_cnpj=$_GET["cpfcnpj1"];	
				$seleciona=mysqli_query($conexao, "select * from clientes where nome = $nome");
				while($campo=mysqli_fetch_array($seleciona)){?>
				<tr>
					<td> <?=$campo["nome"]?> </td>
					<td> <?=$campo["cpf_cnpj"]?> </td>
				</tr>
			<?php }?>
		</table>
	</body>
</html>

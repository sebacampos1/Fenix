	function checkInput(){
        if(document.getElementById('Fisica').checked){
            limpartudo();
            document.getElementById('cpfcnpj1').value=('CPF:');
            document.getElementById('cpfcnpj1').maxlength =3;
            document.getElementById('cpfcnpj1').size=(2);
            document.getElementById('rginscricao').value=('R.G.:');
            document.getElementById('rginscricao1').size=(13);
            document.getElementById('dtnasc').value=('Dt. nascim.:');
            document.getElementById('dtnasc1').size=(7);
            document.getElementById('nomemae').value=('Nome da mãe  :');
            document.getElementById('nomemae1').size=(50);
            document.getElementById('cpfcnpj2').value = '';
            
        }
        if(document.getElementById('Juridica').checked){
            limpartudo();
            document.getElementById('cpfcnpj1').value=('CNPJ:');
            document.getElementById('cpfcnpj1').size=(2);
            document.getElementById('rginscricao').value=('I.E.:');
            document.getElementById('rginscricao1').size=(13);
            document.getElementById('dtnasc').value=('Dt. cadast.:');
            document.getElementById('dtnasc1').size=(7);
            document.getElementById('nomemae').value=('Nome Fantasia:');
            document.getElementById('nomemae1').size=(50);
            document.getElementById('cpfcnpj2').value = '';
        
            
        }
    }

	function pesquisacep(valor) {
        var cep = valor.replace(/\D/g, '');
        if (cep!="") {
            var validacep = /^[0-9]{8}$/;          
			if(validacep.test(cep)) {
                var script = document.createElement('script');
                script.src = 'https://viacep.com.br/ws/'+ cep + '/json/?callback=meu_callback';
                document.body.appendChild(script);
            }
            else {
				limparcampos();
            }
        } 
        else {
			alert(cep.length)
			limparcampos();
        }
    }
	function meu_callback(conteudo) {
        if (!("erro" in conteudo)) {
            document.getElementById('rua').value=(conteudo.logradouro);
            document.getElementById('bairro').value=(conteudo.bairro);
            document.getElementById('cidade').value=(conteudo.localidade);
            document.getElementById('uf').value=(conteudo.uf);
        }
        else {
            limparcampos();
            alert("CEP não encontrado.");
            document.getElementById('cep').focus();
        }
    }
	function limparcampos() {
        document.getElementById('rua').value=("");
        document.getElementById('bairro').value=("");
        document.getElementById('cidade').value=("");
        document.getElementById('uf').value=("");
        document.getElementById('cep').value=("");
        document.getElementById('num').value=("");
        document.getElementById('complemento').value=("");
    }

	function limpartudo() {
        document.getElementById('cpfcnpj2').value=("");
        document.getElementById('nome').value=("");
        document.getElementById('rginscricao1').value=("");
        document.getElementById('dtnasc1').value=("");
        document.getElementById('nomemae1').value=("");
        document.getElementById('contato').value=("");
        document.getElementById('telfixo').value=("");
        document.getElementById('cel1').value=("");
        document.getElementById('cel2').value=("");
        document.getElementById('email').value=("");
        document.getElementById('site').value=("");
        document.getElementById('cep').value=("");
        document.getElementById('rua').value=("");
        document.getElementById('num').value=("");
        document.getElementById('complemento').value=("");
        document.getElementById('bairro').value=("");
        document.getElementById('cidade').value=("");
        document.getElementById('uf').value=("");
        document.getElementById('obs').value=("");
        
    }
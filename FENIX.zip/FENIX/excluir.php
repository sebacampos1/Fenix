<?php
	include("conecta.php");
	$recid=$_GET["idexc"];
	mysqli_query($conexao, "delete from cademail where id = $recid");
	header("location:lista.php");
?>
